<?
	session_start();
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<html>

<head>
 
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">

<link rel="stylesheet" type="text/css" href="css/common.css">


	<style>
		.button{
			background-color: white;
			width: 150px;
			height: 150px;
			margin:20px;
			border-radius:15px;
		}
	</style></head>


<body>
<div>

	<div id="header">
 
   <? include "./lib/top_login1.php"; ?>

	  </div> 
<div>
<a href="./free/list.php">post</a>
</div>
<center><img style="margin-top:100px;height:150px" src="./dding/logo.Png"></center>
	<center><a href="./dding/p1.html"><button class="button" style="background-image:url(./dding/h.png);background-size:150px 150px"></button></a>
	<a href="./dding/p4.html"><button class="button" style="background-image: url(./dding/j.png); background-size:150px 150px"></button></a>
	<a href="./dding/p3.html"><button class="button" style="background-image: url(./dding/y.png); background-size:150px 150px"></button></a>
	<a href="./dding/p2.html"><button class="button" style="background-image: url(./dding/i.png); background-size:150px 150px"></button></a></center>
<!-- end of content -->

</div> 
<!-- end of wrap -->

</body>

</html>
